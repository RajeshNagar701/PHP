/*
SQLyog Professional v13.1.1 (64 bit)
MySQL - 10.4.22-MariaDB : Database - lv_relations
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lv_relations` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `lv_relations`;

/*Table structure for table `brands` */

DROP TABLE IF EXISTS `brands`;

CREATE TABLE `brands` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `brands` */

insert  into `brands`(`id`,`name`,`description`,`created_at`,`updated_at`) values 
(1,'Brand Name 1','Brand Description 1','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(2,'Brand Name 2','Brand Description 2','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(3,'Brand Name 3','Brand Description 3','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(4,'Brand Name 4','Brand Description 4','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(5,'Brand Name 5','Brand Description 5','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(6,'Brand Name 6','Brand Description 6','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(7,'Brand Name 7','Brand Description 7','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(8,'Brand Name 8','Brand Description 8','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(9,'Brand Name 9','Brand Description 9','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(10,'Brand Name 10','Brand Description 10','2022-01-30 06:35:47','2022-01-30 06:35:47');

/*Table structure for table `brands_dealers` */

DROP TABLE IF EXISTS `brands_dealers`;

CREATE TABLE `brands_dealers` (
  `id` bigint(20) NOT NULL,
  `dealers_id` bigint(20) DEFAULT NULL,
  `brands_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `brands_dealers` */

insert  into `brands_dealers`(`id`,`dealers_id`,`brands_id`) values 
(0,1,NULL),
(2,1,3),
(3,3,4),
(4,5,10),
(5,6,6),
(6,10,7),
(7,9,2),
(8,4,4),
(9,3,5),
(10,4,9),
(11,10,8),
(12,6,2),
(13,5,4),
(14,7,9),
(15,2,5);

/*Table structure for table `dealers` */

DROP TABLE IF EXISTS `dealers`;

CREATE TABLE `dealers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `brand_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `dealers` */

insert  into `dealers`(`id`,`brand_id`,`name`,`location`,`description`,`created_at`,`updated_at`) values 
(1,1,'Dealer Name 1','Dealer Location 1','Dealer Description 1','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(2,1,'Dealer Name 2','Dealer Location 2','Dealer Description 2','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(3,3,'Dealer Name 3','Dealer Location 3','Dealer Description 3','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(4,4,'Dealer Name 4','Dealer Location 4','Dealer Description 4','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(5,3,'Dealer Name 5','Dealer Location 5','Dealer Description 5','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(6,6,'Dealer Name 6','Dealer Location 6','Dealer Description 6','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(7,7,'Dealer Name 7','Dealer Location 7','Dealer Description 7','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(8,3,'Dealer Name 8','Dealer Location 8','Dealer Description 8','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(9,9,'Dealer Name 9','Dealer Location 9','Dealer Description 9','2022-01-30 06:35:47','2022-01-30 06:35:47'),
(10,4,'Dealer Name 10','Dealer Location 10','Dealer Description 10','2022-01-30 06:35:47','2022-01-30 06:35:47');

/*Table structure for table `failed_jobs` */

DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `failed_jobs` */

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `migrations` */

insert  into `migrations`(`id`,`migration`,`batch`) values 
(1,'2014_10_12_000000_create_users_table',1),
(2,'2014_10_12_100000_create_password_resets_table',1),
(3,'2019_08_19_000000_create_failed_jobs_table',1),
(4,'2019_12_14_000001_create_personal_access_tokens_table',1),
(5,'2022_01_30_062929_create_dealers_table',1),
(6,'2022_01_30_062953_create_brands_table',1);

/*Table structure for table `password_resets` */

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `password_resets` */

/*Table structure for table `personal_access_tokens` */

DROP TABLE IF EXISTS `personal_access_tokens`;

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `personal_access_tokens` */

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `users` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
