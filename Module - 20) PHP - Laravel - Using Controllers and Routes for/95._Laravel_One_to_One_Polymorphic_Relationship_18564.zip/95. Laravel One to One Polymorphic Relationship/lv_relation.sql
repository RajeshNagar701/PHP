/*
SQLyog Professional v13.1.1 (64 bit)
MySQL - 10.4.22-MariaDB : Database - lv_relations
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lv_relations` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `lv_relations`;

/*Table structure for table `cars` */

DROP TABLE IF EXISTS `cars`;

CREATE TABLE `cars` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `cars` */

insert  into `cars`(`id`,`name`,`brand`,`created_at`,`updated_at`) values 
(1,'Model-4','BMW','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(2,'Model-4','Cadillac','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(3,'Model-3','Maserati','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(4,'Model-2','BMW','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(5,'Model-4','Skoda','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(6,'Model-5','Maserati','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(7,'Model-5','Mercedes','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(8,'Model-3','Maserati','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(9,'Model-1','Skoda','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(10,'Model-4','Mercedes','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(11,'Model-5','Cadillac','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(12,'Model-4','Maserati','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(13,'Model-3','BMW','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(14,'Model-2','Maserati','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(15,'Model-1','Skoda','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(16,'Model-4','Cadillac','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(17,'Model-1','Skoda','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(18,'Model-2','BMW','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(19,'Model-3','Cadillac','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(20,'Model-3','BMW','2022-03-13 07:35:31','2022-03-13 07:35:31'),
(21,'Model-1','BMW','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(22,'Model-1','Mercedes','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(23,'Model-2','Cadillac','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(24,'Model-2','Maserati','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(25,'Model-3','BMW','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(26,'Model-5','Maserati','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(27,'Model-1','Maserati','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(28,'Model-5','Cadillac','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(29,'Model-2','Skoda','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(30,'Model-1','Skoda','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(31,'Model-4','Skoda','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(32,'Model-2','Cadillac','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(33,'Model-2','Mercedes','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(34,'Model-2','Skoda','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(35,'Model-5','BMW','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(36,'Model-5','BMW','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(37,'Model-5','BMW','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(38,'Model-2','BMW','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(39,'Model-3','BMW','2022-03-13 07:40:30','2022-03-13 07:40:30'),
(40,'Model-5','Mercedes','2022-03-13 07:40:30','2022-03-13 07:40:30');

/*Table structure for table `customers` */

DROP TABLE IF EXISTS `customers`;

CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `car_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `customers` */

insert  into `customers`(`id`,`name`,`address`,`car_id`,`created_at`,`updated_at`) values 
(1,'Katelyn Johnson','Culpa sint eum occaecati sit veritatis similique quo. Veniam est quo eaque dolore enim. Saepe possimus reiciendis eum expedita. Repellat vero sed et modi deleniti.',12,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(2,'Miss Bulah Kiehn Jr.','Sed sed magnam quis debitis adipisci voluptas quia. Ad quisquam officiis alias et consequuntur cupiditate. Sed est eos maxime sit nobis porro.',2,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(3,'Chanelle Morar Sr.','Optio et asperiores earum quia et nihil id. Libero doloribus error dolor ex eius eveniet impedit at. Sit pariatur sunt perferendis aut et itaque. Dolores fugit nisi vitae modi illum est.',18,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(4,'Magdalen Grant DDS','Sed neque porro qui minima at. In omnis repudiandae earum cumque eum odit. Eveniet vitae non aut qui perspiciatis. Iusto temporibus recusandae incidunt ab rerum voluptas.',9,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(5,'Ms. Madie Watsica','Maiores in quia in. Facere nihil sed vel sapiente. Ut quia numquam voluptatem aut laboriosam consequatur facilis. Harum quo reiciendis quo ad dolor.',3,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(6,'Letitia Lindgren PhD','Et et saepe alias quis quo tempora ab. Est molestiae et provident debitis sapiente.',5,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(7,'Winston Mohr','Sit consequatur similique odio. Quos est assumenda quia amet. Nemo illo aut consectetur numquam sit. Qui nam magnam veniam quo.',16,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(8,'Rory Kulas','Dignissimos minima eaque sit tempore neque voluptatem quaerat. Ipsam debitis iure praesentium hic facilis perspiciatis. Ea qui dolor vel eos odit voluptates. Libero quia assumenda ad sapiente id.',17,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(9,'Nya Leuschke','Id doloribus tempora ullam in. Voluptas voluptate voluptatem ad et delectus. Aut praesentium minus et.',1,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(10,'Adam Bergstrom','Repudiandae aut ut fugit a accusamus repellat. Dolor aut amet nisi odit soluta laboriosam incidunt.',18,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(11,'Oscar Crooks','Omnis sequi necessitatibus error minima. Et est similique officia eius saepe aut officia. Vero sit est sint dolore sit dolorem.',4,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(12,'Waylon Abbott','Deleniti eveniet repellat sed placeat saepe recusandae rerum. Qui officiis placeat consectetur consequatur. In occaecati quod est quas.',14,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(13,'Dr. Mekhi Raynor IV','Ea fugit est quia numquam quos. Quis consectetur fugit assumenda et est. Nobis unde sit libero praesentium.',18,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(14,'Emmett Macejkovic','Deserunt optio assumenda qui. Deleniti labore rerum est nihil iusto delectus nemo. Omnis officia iste eos.',1,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(15,'Miss Lelah Swift','Odio quis similique quo quam qui. Quia quo officiis aliquid et et molestiae.',10,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(16,'Ms. Alyce Runolfsdottir Sr.','Iste temporibus dolor eligendi ut. Magni dolor quas sit sunt molestiae repellat. Amet amet quos dolores aperiam et et cum.',10,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(17,'Leann Jacobs DVM','Accusantium veniam quo saepe qui vel dolorem dolor. Voluptates pariatur ullam quis nulla reprehenderit ut in. Provident numquam et similique occaecati. Incidunt exercitationem fugiat nemo esse.',7,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(18,'Mr. Elliot Hill','Eum harum modi earum eos laboriosam placeat eum. Quo rem aliquid ab nihil dolores nam. Impedit cupiditate natus blanditiis molestias. Sed ut fugit unde eos totam id quis.',2,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(19,'Kendra Purdy','Aut atque sit fuga quia. Tempora vel suscipit dolorem tempora nisi et. Est placeat dolorem nostrum.',17,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(20,'Mr. Nicholas Kunde','Non eveniet ullam quis. Qui consectetur quia harum dolor veniam qui laudantium. Saepe sed quae laudantium non. Eius assumenda qui inventore culpa aut quidem.',15,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(21,'Shanny Kling','Quo voluptatem architecto nemo odit. Et explicabo nisi minus vel ipsa. Quia accusamus sint tenetur quasi ea tenetur recusandae. Est eos et quia qui asperiores sunt rem. Excepturi ut sed qui.',4,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(22,'Ova Daugherty','Molestiae et non qui deserunt distinctio asperiores. Consequatur ea iure quia quas tempore. Facere iste earum blanditiis aperiam.',17,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(23,'Anabel Okuneva I','Expedita officia vel modi consequuntur autem autem ex. Ea quibusdam assumenda id impedit nihil aut aliquid. Earum totam tempore velit. Sit aut sit laudantium distinctio sit id.',16,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(24,'Cleora Schoen Sr.','Cumque enim voluptas quis et vel eligendi. Qui aut dolores ratione ut sed. Aut et ullam unde atque aperiam. Voluptatem natus perferendis facere.',18,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(25,'Keanu Corkery','Aut dicta est voluptatibus illum sed aut laudantium. Labore quo aut quia. Illo aspernatur ea et dolore ut porro. Vel distinctio vitae autem omnis.',3,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(26,'Henderson Predovic II','Sed aut fuga eligendi corrupti commodi. Est omnis eos suscipit eum aut. Cum ea itaque excepturi ad error natus voluptatem.',4,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(27,'Miss Lenore Powlowski','Exercitationem sint nihil sunt nihil saepe enim. Quod laudantium amet possimus eveniet.',8,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(28,'Alyce Rempel','At molestiae ea et possimus. Facere eum consequatur et nihil recusandae.',6,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(29,'Alexie Hagenes III','Dolorem facilis ut dolores voluptatum earum. Eius provident officia veritatis velit. Distinctio harum error saepe odio.',19,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(30,'Collin Stracke IV','Occaecati dolorem sunt voluptatem qui. Explicabo dolorem quas laborum. Qui et quod magnam nemo. Quaerat ipsam eaque et labore ipsum. Voluptatibus magnam maxime iusto sit.',16,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(31,'Emiliano O\'Keefe','Eius tempora omnis fugiat nam corrupti aut ipsa. Voluptas exercitationem tempore hic qui doloribus officiis totam. Odio quasi sunt saepe et eum consequatur. Et ex praesentium quasi architecto aut.',8,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(32,'Araceli Witting','Aut hic nisi quaerat distinctio accusantium aut. Suscipit neque et ullam ratione exercitationem quaerat quibusdam. Quidem ad soluta id assumenda atque omnis optio accusamus.',11,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(33,'Jalen Feeney','Voluptatem nostrum qui saepe natus. Veniam nulla suscipit maxime et. Mollitia deleniti non et minima non.',14,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(34,'Giovanni Fritsch','Autem non ipsam inventore suscipit voluptas corrupti dolorum. Minus aut et voluptatem. Tempora quibusdam velit omnis cum est ut sint. Qui voluptates amet quis error ad aut et.',6,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(35,'Mrs. Yasmeen McDermott','Odit culpa excepturi rerum et. Rerum dolorem vitae sed delectus facere ut. Debitis non vitae eum assumenda dolorem recusandae eveniet. Et laboriosam eos atque nulla perferendis nemo quo.',7,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(36,'Jettie Marvin','Quam in iure rerum ipsa. Debitis debitis qui aut sed. Ea non molestias veritatis illo quasi modi non. Quo modi dolores rem ea in.',10,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(37,'Dr. Mikel Durgan Jr.','Odio accusantium eveniet libero. Alias voluptatem corporis ipsa debitis voluptatem animi. Aperiam velit aut rem est et minus explicabo. Enim debitis magni culpa ut exercitationem.',19,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(38,'Eloise Johns','Voluptas ut iure recusandae vel non suscipit quaerat possimus. Eum quas perferendis explicabo exercitationem adipisci autem at est. Accusamus vitae sit quae vel quasi reprehenderit.',2,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(39,'Vanessa Zieme','Eveniet autem vero iure et. Quas quas debitis quidem. Ratione laudantium nulla explicabo qui aut ipsam accusamus. Assumenda similique sint quo itaque. Eligendi accusantium ut quis eum.',9,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(40,'Mrs. Gerda Bayer','Et ratione qui ipsam libero voluptatum aperiam ducimus. Eos consequuntur quo nulla harum. Iure nihil blanditiis nobis molestias praesentium. Velit et similique error sit omnis nam.',6,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(41,'Prof. Haylie Lynch II','Dolorem perferendis aut sapiente illo laudantium. Eum itaque quis culpa recusandae doloribus. Ad suscipit quia accusantium magnam.',11,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(42,'Miss Sarai Fritsch','Laborum dolorum asperiores id aut. Id eos et ut molestias modi. Ut officiis at voluptas sit ut placeat beatae. Sunt labore amet in aut odit.',13,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(43,'Pearlie Schaefer','Voluptatibus laboriosam et perspiciatis iusto rem corporis laboriosam. Deleniti ut ut dolores quae.',17,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(44,'Lavada Rutherford MD','Similique occaecati id nobis alias doloremque nemo quo. Voluptas architecto et fuga voluptas rerum rem. Cum tempore ab asperiores recusandae aut laborum.',5,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(45,'Prof. Agustin Leffler','Tempore delectus voluptas rem sit corporis officiis. Voluptatem sed omnis provident aut eius magnam quaerat magni. Et maiores est aut molestiae enim qui.',4,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(46,'Carmela Cartwright Sr.','Porro ea aut illo et maxime. Eos iste laudantium cupiditate ea. Perferendis et vel non dicta suscipit aut et quos.',15,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(47,'Frankie Cummings','Quas non laborum corporis tempore ad praesentium. Debitis rerum a et. Fuga quis libero porro cumque. Dolorem dolorem nam beatae fuga deleniti.',11,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(48,'Chaim Larkin','Quo praesentium iusto alias. Rerum delectus porro tempora et quia. Aut soluta nulla voluptatum aperiam hic aut nihil. Voluptas necessitatibus quasi quos reiciendis aut.',4,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(49,'Yessenia Cronin III','Vel quos exercitationem ea reprehenderit nam illum est. In vitae sit explicabo nam. Dolores sequi doloribus eos et. Nemo dolorem iusto est necessitatibus nesciunt voluptas laboriosam.',3,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(50,'Titus Howell','Quis repellat saepe adipisci ut ut. Delectus inventore aut nostrum quo beatae. Dolore laborum ipsam et aut eveniet.',18,'2022-03-13 07:35:31','2022-03-13 07:35:31'),
(51,'Dr. Federico Schmitt','Ut nostrum labore porro dicta mollitia. Ut praesentium deleniti et dicta nostrum voluptatem consequatur. Tempore voluptas tempore ut quas. Quisquam in nostrum aut a aliquam inventore voluptatem.',14,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(52,'Amalia Walter','Ducimus voluptatibus est molestiae a. Illum est omnis sint et ex. Voluptatem sit blanditiis blanditiis aperiam et.',20,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(53,'Alia Sipes','Quas quaerat officia in eos exercitationem explicabo. Iusto distinctio aliquid cum cum iure dignissimos rerum et. Unde et quis possimus quia.',15,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(54,'Miss Audrey Dietrich IV','Qui quasi fugit beatae aliquam voluptates. Nostrum nemo aut sit dolor dolorem. Et doloribus vitae nihil dolore dicta quos tenetur. Nemo culpa aliquid autem quidem ut facere explicabo.',7,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(55,'Rosalyn Stiedemann','Aliquam alias est itaque quisquam. Dolor perferendis tenetur tempore illum ratione eos. Blanditiis dolorem id labore unde fuga tempore quia. Quis eos laborum harum libero.',7,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(56,'Chelsea Kunde','Et architecto aut eos possimus quia laudantium quis. Eum nam tempore molestias aut quos. Doloribus blanditiis omnis molestiae cupiditate ea alias.',5,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(57,'Prof. Brook Blick','Distinctio explicabo aliquam aspernatur. Laudantium aperiam excepturi eum nihil. Excepturi non rerum numquam sapiente ea fuga. Est deleniti et iusto corrupti quidem et.',1,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(58,'Dexter VonRueden','Dolorem natus accusamus et vero incidunt. Exercitationem aut rerum recusandae eum esse ut architecto. Aliquid temporibus dolorem iusto quis et.',1,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(59,'Norbert Reichert','Quo illo nam pariatur corporis. Nemo distinctio earum et qui quisquam totam odit.',19,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(60,'Aaron Kuhic','Voluptatum voluptas officiis fugit enim fugiat qui. Nihil omnis eligendi sint omnis nostrum reiciendis dignissimos non. Hic quia repellat est labore. Consequatur et sit nam.',10,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(61,'Estel Hodkiewicz','Libero et aut adipisci repudiandae. Eos facilis natus veniam. Odio possimus id rerum consequatur praesentium ea. Consectetur libero hic et a error sed provident. Hic hic aut qui et vel.',8,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(62,'Arne Hirthe PhD','Rerum voluptates ad dolorem. Explicabo architecto qui qui ex velit distinctio sed distinctio. Alias totam dolores consequuntur impedit voluptatem et.',9,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(63,'Laila McGlynn','Unde cum et voluptatem aspernatur. Nam quo rerum eos consequuntur. Voluptas fugit dolorum perferendis. Cumque necessitatibus quasi incidunt ut.',6,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(64,'Dr. Stan Muller','Officia ea dolorem facere sed ut. Dolor cum eos quibusdam. Quia rem amet illo vitae. Ut blanditiis omnis ea ullam.',10,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(65,'Ms. Connie Heidenreich','Dolor beatae vitae eos deleniti. Doloremque nobis iste accusantium saepe et magnam id. Id cum quis ipsa consequuntur.',8,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(66,'Mr. Gordon Klocko DVM','Laborum mollitia est dolor ea quo quia possimus. Ut magni culpa id voluptatum debitis et. Debitis velit et mollitia nisi. Saepe quaerat natus voluptas optio qui expedita.',2,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(67,'Ida Kub','Placeat ut omnis et. Aspernatur sit nihil aliquid reiciendis. Qui porro ipsum et quia illum.',18,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(68,'Prof. Breanna Aufderhar I','Voluptatibus accusamus est perferendis ut. Quia saepe necessitatibus rem vel. Error id cumque repellendus non ut doloremque qui.',9,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(69,'Emil Monahan','Minima qui incidunt natus architecto blanditiis est. Vero id aut eius aperiam qui sit. Rerum tenetur et id est sed. Earum perspiciatis vel nobis fuga cumque.',10,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(70,'Heaven Tromp','Illo et aliquid animi quod sunt et repellat. Voluptas recusandae expedita quam provident quidem. Delectus dolorum possimus corporis eveniet illo. Mollitia nobis quia quod nihil.',13,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(71,'Ms. Delilah Hickle Sr.','Iste modi est cupiditate sed. Reprehenderit quod distinctio aut soluta quae voluptas beatae. Consequuntur totam in ratione consequatur quo.',2,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(72,'Terry Lebsack','Qui rem provident velit incidunt possimus ut exercitationem. Voluptatem est asperiores molestiae illo eligendi exercitationem. Dolor ratione voluptatem nisi ea neque at enim.',9,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(73,'Jewel Walker','Sint et et illum quis aperiam. Quia ad ad soluta. Cum dolor illo optio accusamus sit omnis expedita. Necessitatibus omnis ut molestiae facilis.',10,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(74,'Dr. Brionna Kerluke','Rerum reprehenderit et hic error in dolorum. Praesentium illum non neque unde esse. Nisi aut aut consequatur et expedita.',12,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(75,'Susan Smith','Rerum voluptas autem eos vero aut. Dolor non qui ratione error ea error accusantium. Ut harum minus aut ut dolorum tempore qui. Dolorum hic tempore consectetur voluptatum in excepturi.',12,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(76,'Verona Cummings','Odio nemo beatae recusandae. Rerum eos enim ut. Sunt nemo impedit aliquid aut nam.',2,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(77,'Prof. Dessie Zemlak','Repellendus aut voluptatem culpa enim nam vero aliquam. Quibusdam nihil illo dolor laborum rerum ea commodi. Ipsa vel ut quibusdam sit sint qui placeat.',10,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(78,'Kayley Corkery','Et ea ullam autem voluptatum sit officia dolorem. Exercitationem fugiat facilis natus.',8,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(79,'Maud Olson','Dicta qui et labore sint omnis nihil consequatur. Ea ut labore et molestiae et quia. Et officiis dolores nostrum. Ipsa vel in aut iusto quis. Laborum dignissimos dolor dicta asperiores.',18,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(80,'Onie Harber DDS','Facere consequatur labore asperiores porro. Est officia et voluptates sit eius facere magnam.',13,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(81,'Alisha Huel','Fugiat praesentium sunt maxime neque fugit est. Tenetur aliquid rerum omnis vel velit aut minima. Fugit modi libero consequuntur vitae debitis.',9,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(82,'Mrs. Jennie McDermott','Corrupti provident eius ut ipsum. Nisi doloremque aperiam consequuntur non nihil consequatur rem. Eligendi id suscipit dolorem est facere doloremque. Ad quia atque dolor omnis.',8,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(83,'Mrs. Fannie Mante Sr.','Eos atque minus id illo in ex eaque. Corporis ut sit id eum. Totam ipsam dolor delectus fugiat nisi omnis ut saepe. Dignissimos omnis accusantium consequatur dolores aut.',20,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(84,'Crystal Kautzer','Quas omnis nulla ipsam quis consequatur alias. Odit sit fugiat quis qui asperiores veniam.',1,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(85,'Prof. Reuben Little','Possimus facere veniam ab quasi odio voluptas harum. Sed molestiae quisquam necessitatibus commodi voluptate minima. Quia qui qui quo consequatur.',10,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(86,'Mary Corkery','Consequatur eius qui voluptas vel odit consectetur non. Enim facere sunt reiciendis et provident sunt nihil. Earum voluptates repellendus nostrum consequuntur doloremque.',9,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(87,'Mariam Nienow','Suscipit expedita sed velit eum. Voluptatem consequatur aperiam omnis doloremque. Est nulla rerum sed placeat. A ab quos quisquam numquam omnis debitis iusto.',5,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(88,'Mrs. Elsa Reinger','Qui facilis ad molestiae commodi recusandae quisquam. Voluptas maxime itaque aut repellat et. Saepe neque perferendis maiores. Iste est sit libero unde quia.',11,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(89,'Miss Clemmie Oberbrunner III','Sapiente qui eum quas. Voluptate porro at autem qui fugiat sed dicta. Sit et numquam sunt iste dolorem deleniti adipisci.',3,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(90,'Prof. Renee Thompson','Voluptatem provident sapiente et impedit qui expedita vel rerum. Omnis dolor quis eius veritatis.',5,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(91,'Judge Hamill','Incidunt vel voluptatem delectus nisi deserunt quod. Officia rem recusandae sequi excepturi. Ut natus quaerat delectus et nesciunt.',16,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(92,'Fiona Ledner','Vitae vero delectus rem eum quaerat. Nesciunt odit saepe nisi esse. A dolorem quia veritatis expedita.',16,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(93,'Prof. Richie Kunze I','Ut et consequatur sed et velit architecto. Ratione repudiandae aut ut sint quia laudantium neque.',11,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(94,'Julius West','Quia iste et ipsam maxime ad sint amet. Deleniti dolorem est distinctio rerum cum dolorem nemo. Architecto nihil ipsam nihil provident.',8,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(95,'Adrienne Cruickshank','Nesciunt aut eius est aut sunt magnam. Velit dolor quae iure modi repudiandae quod quam quis. Rerum praesentium et sit occaecati.',11,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(96,'Shanny Wisozk','Excepturi vel exercitationem et ut labore sed. Sed voluptas enim quaerat soluta. Autem illum est temporibus aut dolor vel. Delectus eos est consequatur.',5,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(97,'Michale Sawayn','Vel voluptas ea cum eveniet ipsa consectetur. Consectetur dolor et ipsam ducimus et. Quis suscipit reprehenderit unde est.',20,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(98,'Burnice Hessel','Dolor repellendus deleniti dolorem magnam. Quae velit voluptatem aliquid est. Praesentium dignissimos voluptates fugiat aut eius temporibus voluptatem in.',4,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(99,'Kathleen Kulas','Voluptates autem beatae laudantium. Et architecto architecto sint accusamus accusantium. Ut a voluptas eaque eligendi omnis quos amet. Maxime ducimus et est dolorum beatae in.',1,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(100,'Ottis Leannon','Architecto cum eos eos omnis sit. Cum aspernatur explicabo alias repellendus voluptatem nulla nulla ducimus. Porro minus ut vel rerum saepe.',8,'2022-03-13 07:40:30','2022-03-13 07:40:30');

/*Table structure for table `images` */

DROP TABLE IF EXISTS `images`;

CREATE TABLE `images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imagable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imagable_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `images_imagable_type_imagable_id_index` (`imagable_type`,`imagable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `images` */

insert  into `images`(`id`,`url`,`imagable_type`,`imagable_id`,`created_at`,`updated_at`) values 
(1,'https://via.placeholder.com/640x480.png/0044cc?text=deleniti','App\\Models\\Car',3,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(2,'https://via.placeholder.com/640x480.png/00ccbb?text=at','App\\Models\\Customer',15,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(3,'https://via.placeholder.com/640x480.png/00cc88?text=ipsum','App\\Models\\Car',20,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(4,'https://via.placeholder.com/640x480.png/000077?text=provident','App\\Models\\Car',1,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(5,'https://via.placeholder.com/640x480.png/004499?text=ut','App\\Models\\Customer',12,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(6,'https://via.placeholder.com/640x480.png/0077ee?text=ut','App\\Models\\Car',10,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(7,'https://via.placeholder.com/640x480.png/001177?text=impedit','App\\Models\\Customer',17,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(8,'https://via.placeholder.com/640x480.png/00ccbb?text=veritatis','App\\Models\\Car',19,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(9,'https://via.placeholder.com/640x480.png/00cccc?text=aut','App\\Models\\Customer',3,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(10,'https://via.placeholder.com/640x480.png/00cc33?text=sed','App\\Models\\Customer',10,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(11,'https://via.placeholder.com/640x480.png/000022?text=delectus','App\\Models\\Customer',16,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(12,'https://via.placeholder.com/640x480.png/007788?text=id','App\\Models\\Customer',2,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(13,'https://via.placeholder.com/640x480.png/0066dd?text=culpa','App\\Models\\Car',8,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(14,'https://via.placeholder.com/640x480.png/007777?text=et','App\\Models\\Customer',1,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(15,'https://via.placeholder.com/640x480.png/00aadd?text=praesentium','App\\Models\\Customer',18,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(16,'https://via.placeholder.com/640x480.png/00aa22?text=mollitia','App\\Models\\Car',13,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(17,'https://via.placeholder.com/640x480.png/005522?text=inventore','App\\Models\\Customer',20,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(18,'https://via.placeholder.com/640x480.png/006688?text=blanditiis','App\\Models\\Car',3,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(19,'https://via.placeholder.com/640x480.png/005588?text=iste','App\\Models\\Customer',11,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(20,'https://via.placeholder.com/640x480.png/0011ee?text=et','App\\Models\\Car',12,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(21,'https://via.placeholder.com/640x480.png/003311?text=et','App\\Models\\Car',20,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(22,'https://via.placeholder.com/640x480.png/009944?text=quisquam','App\\Models\\Customer',11,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(23,'https://via.placeholder.com/640x480.png/00bbee?text=voluptatem','App\\Models\\Customer',5,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(24,'https://via.placeholder.com/640x480.png/00aa11?text=eos','App\\Models\\Customer',16,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(25,'https://via.placeholder.com/640x480.png/0099cc?text=magni','App\\Models\\Car',15,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(26,'https://via.placeholder.com/640x480.png/004499?text=eveniet','App\\Models\\Car',6,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(27,'https://via.placeholder.com/640x480.png/0033dd?text=ipsam','App\\Models\\Customer',7,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(28,'https://via.placeholder.com/640x480.png/0022cc?text=magni','App\\Models\\Car',19,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(29,'https://via.placeholder.com/640x480.png/009944?text=et','App\\Models\\Car',8,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(30,'https://via.placeholder.com/640x480.png/006622?text=quo','App\\Models\\Customer',18,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(31,'https://via.placeholder.com/640x480.png/00aa55?text=nisi','App\\Models\\Customer',2,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(32,'https://via.placeholder.com/640x480.png/009922?text=nisi','App\\Models\\Customer',15,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(33,'https://via.placeholder.com/640x480.png/007744?text=aut','App\\Models\\Car',6,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(34,'https://via.placeholder.com/640x480.png/0022cc?text=voluptate','App\\Models\\Customer',12,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(35,'https://via.placeholder.com/640x480.png/002277?text=et','App\\Models\\Customer',8,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(36,'https://via.placeholder.com/640x480.png/00aa55?text=voluptatum','App\\Models\\Car',10,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(37,'https://via.placeholder.com/640x480.png/005533?text=itaque','App\\Models\\Car',18,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(38,'https://via.placeholder.com/640x480.png/006611?text=sed','App\\Models\\Customer',10,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(39,'https://via.placeholder.com/640x480.png/000011?text=cumque','App\\Models\\Customer',1,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(40,'https://via.placeholder.com/640x480.png/00ee33?text=quas','App\\Models\\Car',18,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(41,'https://via.placeholder.com/640x480.png/009966?text=occaecati','App\\Models\\Customer',10,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(42,'https://via.placeholder.com/640x480.png/001111?text=vel','App\\Models\\Car',12,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(43,'https://via.placeholder.com/640x480.png/009944?text=praesentium','App\\Models\\Customer',14,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(44,'https://via.placeholder.com/640x480.png/0055ee?text=exercitationem','App\\Models\\Customer',19,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(45,'https://via.placeholder.com/640x480.png/00ee88?text=quo','App\\Models\\Customer',5,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(46,'https://via.placeholder.com/640x480.png/00bbbb?text=quia','App\\Models\\Customer',2,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(47,'https://via.placeholder.com/640x480.png/008855?text=qui','App\\Models\\Car',4,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(48,'https://via.placeholder.com/640x480.png/004488?text=tempore','App\\Models\\Car',18,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(49,'https://via.placeholder.com/640x480.png/004488?text=aut','App\\Models\\Customer',2,'2022-03-13 07:40:30','2022-03-13 07:40:30'),
(50,'https://via.placeholder.com/640x480.png/0033ee?text=voluptates','App\\Models\\Customer',18,'2022-03-13 07:40:30','2022-03-13 07:40:30');

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `migrations` */

insert  into `migrations`(`id`,`migration`,`batch`) values 
(2,'2014_10_12_100000_create_password_resets_table',1),
(3,'2019_08_19_000000_create_failed_jobs_table',1),
(4,'2019_12_14_000001_create_personal_access_tokens_table',1),
(5,'2022_01_30_062929_create_dealers_table',1),
(6,'2022_01_30_062953_create_brands_table',1),
(7,'2014_10_12_000000_create_users_table',2),
(8,'2022_02_11_155845_create_crud_operations_table',3),
(9,'2022_02_26_071614_create_jobs_table',4),
(10,'2022_03_13_061001_create_cutomers_table',5),
(11,'2022_03_13_061021_create_cars_table',5),
(12,'2022_03_13_072952_create_cars_table',6),
(13,'2022_03_13_073000_create_customers_table',6),
(14,'2022_03_13_073625_create_images_table',7);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
