/*
SQLyog Professional v13.1.1 (64 bit)
MySQL - 10.4.22-MariaDB : Database - lv_relations
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lv_relations` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `lv_relations`;

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `users` */

insert  into `users`(`id`,`first_name`,`last_name`,`email`,`user_name`,`created_at`,`updated_at`) values 
(1,'Lotta','Escreet','lescreet0@a8.net','lescreet0',NULL,NULL),
(2,'Mill','Ingliss','mingliss1@cnn.com','mingliss1',NULL,NULL),
(3,'Josephina','Piotr','jpiotr2@wikipedia.org','jpiotr2',NULL,NULL),
(4,'Krystle','Amoore','kamoore3@yellowbook.com','kamoore3',NULL,NULL),
(5,'Antons','Coverdill','acoverdill4@usgs.gov','acoverdill4',NULL,NULL),
(6,'Nikkie','Odo','nodo5@cyberchimps.com','nodo5',NULL,NULL),
(7,'Diann','Bonhan','dbonhan6@bing.com','dbonhan6',NULL,NULL),
(8,'Trev','D\'Almeida','tdalmeida7@lulu.com','tdalmeida7',NULL,NULL),
(9,'Aldrich','Gretton','agretton8@joomla.org','agretton8',NULL,NULL),
(10,'Virginia','Roughley','vroughley9@apache.org','vroughley9',NULL,NULL),
(11,'Rickard','Tingly','rtinglya@ihg.com','rtinglya',NULL,NULL),
(12,'Garfield','Sprulls','gsprullsb@altervista.org','gsprullsb',NULL,NULL),
(13,'Joanna','Dandison','jdandisonc@google.com.br','jdandisonc',NULL,NULL),
(14,'Robinett','Bryant','rbryantd@google.it','rbryantd',NULL,NULL),
(15,'Bird','Stacy','bstacye@g.co','bstacye',NULL,NULL),
(16,'Betti','Simonaitis','bsimonaitisf@friendfeed.com','bsimonaitisf',NULL,NULL),
(17,'Leighton','Ludy','lludyg@ameblo.jp','lludyg',NULL,NULL),
(18,'Jeana','Stevani','jstevanih@gov.uk','jstevanih',NULL,NULL),
(19,'Katerina','Welham','kwelhami@phoca.cz','kwelhami',NULL,NULL),
(20,'Iolande','Fugere','ifugerej@ehow.com','ifugerej',NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
