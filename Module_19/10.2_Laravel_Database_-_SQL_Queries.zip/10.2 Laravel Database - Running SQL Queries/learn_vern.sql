/*
SQLyog Professional v13.1.1 (64 bit)
MySQL - 10.4.22-MariaDB : Database - learn_vern
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`learn_vern` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `learn_vern`;

/*Table structure for table `customers` */

DROP TABLE IF EXISTS `customers`;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `designation` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;

/*Data for the table `customers` */

insert  into `customers`(`id`,`name`,`email`,`designation`) values 
(1,'Meet','meet@mail.com',''),
(2,'Shubham','shubham@mail.com',''),
(3,'Jigar','jigar@mail.com',''),
(4,'Kishan','kishan@mail.com',''),
(5,'Mukul','mukul@mail.com',''),
(6,'Shraddha','shraddha@mail.com',''),
(7,'Maharshi','maharshi@mail.com',''),
(8,'Kush','kush@mail.com',''),
(9,'Smit','smit@mail.com',''),
(10,'Keval','keval@mail.com',''),
(11,'Maulik','maulik@mail.com',''),
(12,'Parth','parth@mail.com',''),
(14,'Vicky','vicky_updated@mail.com',''),
(17,'Komal','komal@mail.com','Senior HR');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
