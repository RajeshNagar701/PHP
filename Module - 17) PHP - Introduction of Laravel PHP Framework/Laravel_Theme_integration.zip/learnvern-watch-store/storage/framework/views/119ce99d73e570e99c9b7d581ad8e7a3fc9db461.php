<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Start col -->
        <div class="album py-5" style="height:60vh;">
            <div class="row h-100 justify-content-center align-items-center">
                <div class="card border-success" style="margin-top: 4%;max-width: 35rem;padding: 2%;">
                    <?php echo $__env->make('flash_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div>
                        <h2> Forgot Password</h2>
                        <a href="<?php echo e(route('login')); ?>" class="float-end btn btn-outline-dark" style="margin-top: -9%;">Login</a>
                    </div>
                    <hr>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li> <?php echo e($error); ?> </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <form action="<?php echo e(route('send_forgot_password_email')); ?>" method="POST" name="forgotPassForm" enctype="multipart/from-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="email" class="form-control" name="email" id="email"
                                       required="required" placeholder="Enter email">
                            </div>
                            <br>
                            <center>
                                <input type="submit" name="forgot_pass_btn" class="btn btn-outline-success"
                                       value="Send Email">
                            </center>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('store_locator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learnvern-watch-store\resources\views/forgot_password.blade.php ENDPATH**/ ?>