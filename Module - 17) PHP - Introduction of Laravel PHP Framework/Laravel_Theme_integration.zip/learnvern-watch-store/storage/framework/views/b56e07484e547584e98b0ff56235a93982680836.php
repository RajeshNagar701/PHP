<nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.html">LearnVern Store</a>
        <!-- Links -->
        <ul class="navbar-nav">
            <li>
                <form class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
            </li>
        </ul>
        <ul class="navbar-nav">
            <li class="nav-item">
                <a href="cart.html" class="nav-link" style="margin-right: 15px">
                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                    Cart</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle btn" href="#" id="navbarDropdown" role="button"
                   data-bs-toggle="dropdown" aria-expanded="false" style="margin-right: 10px">
                    <?php if(auth()->guard()->guest()): ?> My Account <?php else: ?> <?php echo e(auth()->user()->fname ?? 'My Account'); ?> <?php endif; ?>
                </a>
                <?php if(auth()->guard()->guest()): ?>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="<?php echo e(route('login')); ?>">Login</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('register')); ?>">Register</a></li>
                    </ul>
                <?php else: ?>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="<?php echo e(route('user_profile')); ?>">My Profile</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a></li>
                    </ul>
                <?php endif; ?>
            </li>
        </ul>
    </div>
</nav>
<!-- Header-->
<?php /**PATH C:\xampp\htdocs\learnvern-watch-store\resources\views/header_user.blade.php ENDPATH**/ ?>