<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('user_index');
})->name('home');

Route::controller(\App\Http\Controllers\AuthenticationController::class)->group(function () {
    Route::get('/register', 'register')->name('register');
    Route::post('/register', 'storeUser')->name('store_user');
    Route::get('/login', 'login')->name('login');
    Route::post('/login', 'authenticate')->name('authenticate');
    Route::get('/forgot-password', 'forgotPassword')->name('forgot_password');
    Route::post('/forgot-password', 'sendForgotPasswordEmail')->name('send_forgot_password_email');
    Route::get('/reset-password/{token}', 'resetPassword')->name('reset_password');
    Route::post('/reset-password', 'resetPasswordData')->name('reset_password_data');
    Route::get('/logout', 'logout')->name('logout');
});

Route::controller(\App\Http\Controllers\UserController::class)->group(function () {
    Route::get('/profile', 'userProfile')->name('user_profile');
    Route::put('/profile', 'userProfileUpdate')->name('user_profile_update');
    Route::post('/user-image-update', 'userProfileImageUpdate')->name('user_profile_image_update');
});

