<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;

class UserController extends Controller
{
    public function index()
    {
        return view('controller_view');
    }

    public function nestingView()
    {
        return view('user.nesting_view');
    }

    public function viewExistence()
    {
        if(View::exists('user.view_existence')) {
            return view('user.view_existence');
        } else {
            return 'View is unavailable.';
        }
    }

    public function nameArray()
    {
        if(View::exists('passing_data.name_array_method')) {
            return view('passing_data.name_array_method', ['brand_1' => ['Octavia', 'Superb', 'Fabia'], 'brand_2' => 'Audi', 'brand_3' => 'BMW']);
        } else {
            return 'View is unavailable.';
        }
    }

    public function withFunction($id)
    {
        if(View::exists('passing_data.with_method')) {
            return view('passing_data.with_method')->with('id', $id);
        } else {
            return 'View is unavailable.';
        }
    }

    public function compactFunction()
    {
        $favCars = [
            'Octavia',
            'Superb',
            'A7',
            'XC 90',
            'S 90'
        ];
        $name = 'Meet Shah';
        if(View::exists('passing_data.compact_method')) {
            return view('passing_data.compact_method', compact('favCars', 'name'));
        } else {
            return 'View is unavailable.';
        }
    }


    public function testFunction()
    {
        return 'This is a Test method of User Controller.';
    }

    public function alertComponent(){
        return \view('test');
    }
}
