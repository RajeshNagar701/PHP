<div>
    <div class="alert alert-success" role="alert">
        Welcome to <?php echo e($message); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\learnvern_controllers\resources\views/components/alert.blade.php ENDPATH**/ ?>