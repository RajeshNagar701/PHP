<div>
    <div class="alert alert-success" role="alert">
        Welcome to {{ $message }}
    </div>
</div>
