/*
SQLyog Professional v13.1.1 (64 bit)
MySQL - 10.4.22-MariaDB : Database - learn_vern
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`learn_vern` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `learn_vern`;

/*Table structure for table `customers` */

DROP TABLE IF EXISTS `customers`;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `designation` varchar(40) NOT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4;

/*Data for the table `customers` */

insert  into `customers`(`id`,`name`,`email`,`designation`,`contact`,`created_at`,`updated_at`) values 
(1,'Meet','meet@mail.com','Software Engineer','1234567890','2019-01-15 11:13:49','2019-01-17 11:13:49'),
(2,'Shubham','shubham@mail.com','Associate Consultant','1478963258','2019-02-15 18:14:07','2019-02-15 18:14:07'),
(3,'Jigar','jigar@mail.com','Software Developer','0321456987','2022-01-05 04:14:20','2022-01-05 04:14:20'),
(4,'Kishan','kishan@mail.com','Product Manager','0123456789','2020-06-15 11:14:41','2020-06-15 11:14:41'),
(5,'Mukul','mukul@mail.com','Accountant','4565487895','2020-12-17 07:14:53','2020-12-24 10:14:53'),
(6,'Shraddha','shraddha@mail.com','Quality Analyst','3212321232','2019-08-05 20:05:03','2019-08-05 20:05:03'),
(7,'Maharshi','maharshi@mail.com','Marketing Head','1212212121','2021-09-15 08:08:25','2021-09-15 04:08:25'),
(8,'Kush','kush@mail.com','Sales Head','4532543254','2021-07-30 10:19:39','2021-07-30 10:19:39'),
(9,'Smit','smit@mail.com','Product Manager','1798321221','2021-03-26 21:22:52','2021-03-10 21:22:52'),
(10,'Keval','keval@mail.com','Cyber Security Expert','3265789852','2022-01-01 00:00:00','2022-01-01 00:00:00'),
(11,'Maulik','maulik@mail.com','Accountant','1021021021','2021-04-22 17:16:22','2021-04-22 17:16:22'),
(12,'Parth','parth@mail.com','Software Engineer','3030303030','2020-07-15 15:16:39','2020-06-11 15:16:39'),
(14,'Vicky','vicky_updated@mail.com','Developer','5050505050','2021-11-09 23:25:48','2021-11-09 23:25:48'),
(18,'Komal','komal@mail.com','Senior HR','5412365412','2021-02-26 11:15:01','2021-02-26 11:15:01');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
