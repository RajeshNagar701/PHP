<footer class="py-5 bg-dark">
    <div class="container"><p class="m-0 text-center text-white">Copyright &copy; LearnVern Store 2022</p></div>
</footer>
<?php /**PATH C:\xampp\htdocs\learnvern-watch-store\resources\views/footer_user.blade.php ENDPATH**/ ?>