<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Products</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin_home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Products</li>
            </ol>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    All Products
                    <a href="<?php echo e(route('product.create')); ?>" class="btn btn-outline-primary btn-sm float-end"> + Add Product</a>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('flash_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <table id="datatablesSimple">
                        <thead>
                        <tr>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Sale Price</th>
                            <th>Color</th>
                            <th>Brand</th>
                            <th>Gender</th>
                            <th>Function</th>
                            <th>Stock</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Sale Price</th>
                            <th>Color</th>
                            <th>Brand</th>
                            <th>Gender</th>
                            <th>Function</th>
                            <th>Stock</th>
                            <th>Action</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->product_code); ?></td>
                                <td><?php echo e(\Illuminate\Support\Str::title($product->name)); ?></td>
                                <td><?php echo e($product->price); ?></td>
                                <td><?php echo e($product->sale_price); ?></td>
                                <td><?php echo e(\Illuminate\Support\Str::title($product->color)); ?></td>
                                <td><?php echo e(\Illuminate\Support\Str::title($product->getBrandData->name)); ?></td>
                                <td><?php echo e(\Illuminate\Support\Str::title($product->gender)); ?></td>
                                <td><?php echo e(\Illuminate\Support\Str::title($product->function)); ?></td>
                                <td><?php echo e($product->stock); ?></td>
                                <td style="max-width: 30px">
                                    <a href="<?php echo e(route('product.edit', ['product' => $product->id])); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?php echo e(route('admin_change_product_status', ['id' => $product->id, 'status' => $product->is_active == 1 ? 0 : 1])); ?>" class="btn btn-sm btn-<?php echo e($product->is_active == 1 ? 'danger' : 'success'); ?>"><?php echo e($product->is_active == 1 ? 'Deactivate' : 'Activate'); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learnvern-watch-store\resources\views/admin/product_list.blade.php ENDPATH**/ ?>