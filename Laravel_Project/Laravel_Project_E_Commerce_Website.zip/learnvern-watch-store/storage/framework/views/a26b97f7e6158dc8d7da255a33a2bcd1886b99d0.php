<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Users</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                <li class="breadcrumb-item active">Users</li>
            </ol>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    All Users
                    <a href="<?php echo e(route('admin_user_profile_register')); ?>" class="btn btn-outline-primary btn-sm float-end"> + Add User</a>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('flash_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <table id="datatablesSimple">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Role</th>
                            <th>Email</th>
                            <th>Gender</th>
                            <th>Contact</th>
                            <th>Country</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>Name</th>
                            <th>Role</th>
                            <th>Email</th>
                            <th>Gender</th>
                            <th>Contact</th>
                            <th>Country</th>
                            <th>Action</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->full_name); ?></td>
                                <td><?php echo e($user->role_name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->gender); ?></td>
                                <td><?php echo e($user->contact); ?></td>
                                <td><?php echo e($user->countryData->name); ?></td>
                                <td style="max-width: 30px">
                                    <a href="<?php echo e(route('admin_user_edit', ['id' => $user->id])); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?php echo e(route('admin_change_user_status', ['id' => $user->id, 'status' => $user->is_active == 1 ? 0 : 1])); ?>" class="btn btn-sm btn-<?php echo e($user->is_active == 1 ? 'danger' : 'success'); ?>"><?php echo e($user->is_active == 1 ? 'Deactivate' : 'Activate'); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learnvern-watch-store\resources\views/admin/users_list.blade.php ENDPATH**/ ?>